# Key Overlay
1. Open in Android Studio (or build with the GitHub Actions workflow) and install.
2. Start Shizuku, then grant everything on the home screen.
3. Notification actions: Activate/Deactivate overlay, Edit layout (drag buttons on the game), Settings.
4. Button editor (home screen / Settings): live landscape preview, tap to select, drag to move, per-button
   shape, size, width, opacity, outline, fill / pressed / outline colors, key + extra key, toggle, duplicate, delete.
5. Settings -> Import layout (.json) converts GoyControls-style files, including colors and shapes.
