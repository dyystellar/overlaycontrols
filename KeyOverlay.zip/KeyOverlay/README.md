# Key Overlay
1. Open in Android Studio (or build with the GitHub Actions workflow) and install.
2. Start Shizuku, then grant everything on the home screen.
3. Notification actions: Activate/Deactivate overlay, Edit layout (drag buttons on the game), Settings.
4. Button editor (home screen / Settings): live landscape preview, tap to select, drag to move, per-button
   shape, size, width, opacity, outline, fill / pressed / outline colors, key + extra key, toggle, duplicate, delete.
5. Settings -> Import layout (.json) converts GoyControls-style files, including colors and shapes.
6. Hotbar (home screen -> Hotbar): a separate layer with its own layout, style and key bindings (slots 1-9),
   drawn on top of the normal buttons. Edit it without touching the main button layout.
7. Settings -> Visible mouse cursor (or the MOUSE chip in game): draws a pointer you steer by swiping; taps click where it is.
