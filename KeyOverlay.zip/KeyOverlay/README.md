# Key Overlay
1. Open this folder in Android Studio (it will generate the Gradle wrapper), then Run on your phone.
2. Install Shizuku, start it (Wireless debugging or root), then grant access in step 4 of the app.
3. Grant the other permissions. When overlay + usage + notification permissions are granted, the notification appears
   with: Activate/Deactivate overlay, Edit layout, Settings.
4. The overlay shows only when a package from your list (default: Minecraft) is foreground AND the display is landscape.
5. Chip at top: GAME mode (swipe = mouse, buttons = keys) / MENU mode (touches pass through to the game).

Notes: if the camera doesn't move, turn off "Relative mouse" in Settings and test; behavior of injected
mouse events can vary by Android version / device and whether Bedrock treats them as a real mouse.
