package com.example.keyoverlay

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.Surface
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    companion object {
        const val A_TOGGLE = "toggle"; const val A_EDIT = "edit"; const val A_RELOAD = "reload"; const val A_STOP = "stop"
        const val CH = "overlay"; const val NID = 1
    }

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())
    private var controls: ControlsView? = null
    private var chip: TextView? = null
    private var cursorChip: TextView? = null
    private var bar: LinearLayout? = null
    private lateinit var ctrlLp: WindowManager.LayoutParams
    private var menuMode = false
    private var editMode = false
    private var lastFg: String? = null
    private var lastQ = 0L

    private val tick = object : Runnable { override fun run() { evaluate(); handler.postDelayed(this, 800) } }

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Overlay controls", NotificationManager.IMPORTANCE_LOW))
        startForeground(NID, notification())
        handler.post(tick)
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            A_TOGGLE -> { prefs.active = !prefs.active; refreshNotification(); evaluate() }
            A_EDIT -> { editMode = !editMode; controls?.editMode = editMode; controls?.invalidate(); refreshNotification(); evaluate() }
            A_RELOAD -> { hide(); evaluate() }
            A_STOP -> { hide(); stopSelf() }
        }
        return START_STICKY
    }

    override fun onBind(i: Intent?): IBinder? = null
    override fun onDestroy() { handler.removeCallbacks(tick); hide(); super.onDestroy() }

    // ---------- notification ----------
    private fun svc(action: String, code: Int) = PendingIntent.getService(this, code,
        Intent(this, OverlayService::class.java).setAction(action), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun notification(): Notification {
        val settings = PendingIntent.getActivity(this, 9, Intent(this, SettingsActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentTitle("Key Overlay")
            .setContentText(if (prefs.active) "Overlay armed - shows in landscape games" else "Overlay is off")
            .setOngoing(true)
            .addAction(0, if (prefs.active) "Deactivate overlay" else "Activate overlay", svc(A_TOGGLE, 1))
            .addAction(0, if (editMode) "Done editing" else "Edit layout", svc(A_EDIT, 2))
            .addAction(0, "Settings", settings)
            .build()
    }

    private fun refreshNotification() =
        getSystemService(NotificationManager::class.java).notify(NID, notification())

    // ---------- conditions ----------
    private fun isLandscape(): Boolean {
        val d = (getSystemService(DISPLAY_SERVICE) as DisplayManager).getDisplay(0)
        return d.rotation == Surface.ROTATION_90 || d.rotation == Surface.ROTATION_270
    }

    @Suppress("DEPRECATION")
    private fun foreground(): String? {
        return try {
            val um = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
            val now = System.currentTimeMillis()
            val ev = um.queryEvents(if (lastQ == 0L) now - 6 * 3600_000L else lastQ - 1000, now)
            val e = UsageEvents.Event()
            while (ev.hasNextEvent()) { ev.getNextEvent(e); if (e.eventType == UsageEvents.Event.MOVE_TO_FOREGROUND) lastFg = e.packageName }
            lastQ = now; lastFg
        } catch (_: Throwable) { null }
    }

    private fun evaluate() {
        val gameOk = foreground() in prefs.targetList() && (!prefs.landscapeOnly || isLandscape())
        val want = editMode || (prefs.active && gameOk)
        if (want && controls == null) show() else if (!want && controls != null) hide()
    }

    // ---------- windows ----------
    private fun show() {
        val v = ControlsView(this, prefs).also { it.editMode = editMode }
        ctrlLp = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT).apply {
            alpha = 0.8f // Android 12+ lets touches pass through overlays only at <= 0.8 alpha
            if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        menuMode = false
        wm.addView(v, ctrlLp); controls = v

        fun pill(): TextView = TextView(this).apply { setPadding(36, 12, 36, 12); setTextColor(-1) }
        val modeChip = pill().apply {
            setOnClickListener {
                menuMode = !menuMode
                controls?.passThrough = menuMode
                controls?.releaseAll()
                ctrlLp.flags = if (menuMode) ctrlLp.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                else ctrlLp.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
                wm.updateViewLayout(controls, ctrlLp); label()
            }
        }
        val curChip = pill().apply {
            setOnClickListener { prefs.showCursor = !prefs.showCursor; controls?.refreshCursor(); label() }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0x99000000.toInt())
            addView(modeChip); addView(curChip)
        }
        chip = modeChip; cursorChip = curChip; bar = row; label()
        wm.addView(row, WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 8 })
    }

    private fun label() {
        chip?.text = if (menuMode) "MENU (tap: game)" else "GAME (tap: menu)"
        cursorChip?.text = if (prefs.showCursor) "| MOUSE: ON" else "| MOUSE: OFF"
    }

    private fun hide() {
        controls?.let { it.releaseAll(); try { wm.removeView(it) } catch (_: Exception) {} }
        bar?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        controls = null; chip = null; cursorChip = null; bar = null
    }
}
