package com.example.keyoverlay

import android.graphics.*
import kotlin.math.abs

/** Draws buttons identically in the overlay and in the editor preview. */
object ButtonRenderer {
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val textP = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = Typeface.DEFAULT_BOLD }
    private val selP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0xFF40C4FF.toInt(); pathEffect = DashPathEffect(floatArrayOf(14f, 10f), 0f)
    }
    private val rect = RectF()

    fun diameter(b: Btn, screenH: Float, scale: Float, density: Float) =
        (b.hf * screenH * scale).coerceAtLeast(26f * density)

    fun withAlpha(c: Int, a: Float): Int =
        Color.argb((Color.alpha(c) * a).toInt().coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private fun radiusOf(b: Btn, w: Float, h: Float) = when (b.shape) {
        1 -> b.corner * minOf(w, h)
        2 -> minOf(w, h) / 2f
        else -> -1f
    }

    fun draw(c: Canvas, b: Btn, cx: Float, cy: Float, d: Float, globalAlpha: Float, density: Float) {
        val w = d * b.wr; val h = d
        val a = (b.alpha * globalAlpha).coerceIn(0f, 1f)
        val base = if (b.on) b.onFill else b.fill
        rect.set(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)
        val rad = radiusOf(b, w, h)
        fillP.color = withAlpha(base, a)
        if (rad < 0) c.drawOval(rect, fillP) else c.drawRoundRect(rect, rad, rad, fillP)
        if (b.strokeW > 0f) {
            val sw = b.strokeW * density
            strokeP.strokeWidth = sw; strokeP.color = withAlpha(b.stroke, a)
            rect.inset(sw / 2f, sw / 2f)
            if (rad < 0) c.drawOval(rect, strokeP) else c.drawRoundRect(rect, rad, rad, strokeP)
        }
        val lum = (0.299f * Color.red(base) + 0.587f * Color.green(base) + 0.114f * Color.blue(base)) / 255f
        val dark = Color.alpha(base) > 140 && lum > 0.65f
        textP.color = withAlpha(if (dark) Color.BLACK else Color.WHITE, a.coerceAtLeast(0.75f))
        textP.textSize = minOf(h * 0.34f, w * 1.3f / maxOf(b.label.length, 2))
        c.drawText(b.label, cx, cy - (textP.descent() + textP.ascent()) / 2f, textP)
    }

    fun drawSelection(c: Canvas, b: Btn, cx: Float, cy: Float, d: Float, density: Float) {
        val pad = 5f * density
        val w = d * b.wr + 2 * pad; val h = d + 2 * pad
        rect.set(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)
        selP.strokeWidth = 2.5f * density
        val rad = radiusOf(b, w, h)
        if (rad < 0) c.drawOval(rect, selP) else c.drawRoundRect(rect, rad, rad, selP)
    }

    fun contains(b: Btn, px: Float, py: Float, W: Float, H: Float, scale: Float, density: Float): Boolean {
        val d = diameter(b, H, scale, density)
        val hw = d * b.wr / 2f * 1.1f; val hh = d / 2f * 1.1f
        val dx = px - b.x * W; val dy = py - b.y * H
        return if (b.shape == 0) (dx * dx) / (hw * hw) + (dy * dy) / (hh * hh) <= 1f else abs(dx) <= hw && abs(dy) <= hh
    }
}
