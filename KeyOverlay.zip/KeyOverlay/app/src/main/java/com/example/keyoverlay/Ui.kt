package com.example.keyoverlay

import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import androidx.appcompat.R as AR
import com.google.android.material.R as MR
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.color.MaterialColors
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.slider.Slider

/** Small Material 3 "expressive" helpers: big rounded cards, pill buttons, bold type, dynamic colour. */
object Ui {
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()
    fun col(c: Context, attr: Int) = MaterialColors.getColor(c, attr, Color.MAGENTA)

    fun lp(c: Context, bottomDp: Int = 0) = LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(c, bottomDp) }

    fun vbox(c: Context, padDp: Int = 0) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        val p = dp(c, padDp); setPadding(p, p, p, p)
    }

    fun scrollPage(c: Context): Pair<ScrollView, LinearLayout> {
        val page = vbox(c, 20)
        page.setPadding(dp(c, 16), dp(c, 10), dp(c, 16), dp(c, 14))
        val sv = ScrollView(c)
        sv.setBackgroundColor(col(c, MR.attr.colorSurface))
        sv.isFillViewport = true
        sv.addView(page)
        return sv to page
    }

    fun text(c: Context, s: String, sp: Float, bold: Boolean = false, attr: Int = MR.attr.colorOnSurface): TextView {
        val t = TextView(c)
        t.text = s; t.textSize = sp; t.setTextColor(col(c, attr))
        if (bold) t.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        return t
    }

    fun section(c: Context, title: String, tonal: Boolean = false): Pair<MaterialCardView, LinearLayout> {
        val inner = vbox(c, 14)
        if (title.isNotEmpty()) {
            val t = text(c, title, 15f, true, AR.attr.colorPrimary)
            t.setPadding(0, 0, 0, dp(c, 2))
            inner.addView(t)
        }
        val card = MaterialCardView(c)
        card.radius = dp(c, 24).toFloat()
        card.cardElevation = 0f
        card.strokeWidth = 0
        card.setCardBackgroundColor(col(c, if (tonal) MR.attr.colorSecondaryContainer else MR.attr.colorSurfaceContainerHigh))
        card.layoutParams = lp(c, 8)
        card.addView(inner)
        return card to inner
    }

    private fun button(c: Context, label: String, bg: Int, fg: Int, compact: Boolean, cb: () -> Unit): MaterialButton {
        val b = MaterialButton(c)
        b.text = label
        b.setAllCaps(false)
        b.textSize = if (compact) 13f else 15f
        b.typeface = Typeface.create("sans-serif-medium", Typeface.BOLD)
        b.cornerRadius = dp(c, 22)
        b.insetTop = 0; b.insetBottom = 0
        b.minimumHeight = dp(c, if (compact) 36 else 44)
        b.backgroundTintList = ColorStateList.valueOf(bg)
        b.setTextColor(fg)
        b.layoutParams = lp(c, 4)
        b.setOnClickListener { cb() }
        return b
    }

    fun filled(c: Context, label: String, compact: Boolean = false, cb: () -> Unit) =
        button(c, label, col(c, AR.attr.colorPrimary), col(c, MR.attr.colorOnPrimary), compact, cb)

    fun tonal(c: Context, label: String, compact: Boolean = false, cb: () -> Unit) =
        button(c, label, col(c, MR.attr.colorSecondaryContainer), col(c, MR.attr.colorOnSecondaryContainer), compact, cb)

    fun switchRow(c: Context, label: String, checked: Boolean, cb: (Boolean) -> Unit): MaterialSwitch {
        val s = MaterialSwitch(c)
        s.text = label; s.textSize = 15f; s.setTextColor(col(c, MR.attr.colorOnSurface))
        s.isChecked = checked
        s.setPadding(0, dp(c, 3), 0, dp(c, 3))
        s.layoutParams = lp(c)
        s.setOnCheckedChangeListener { _, v -> cb(v) }
        return s
    }

    fun sliderRow(c: Context, label: String, min: Float, max: Float, start: Float,
                  fmt: (Float) -> String, onChange: (Float) -> Unit, onDone: () -> Unit = {}): LinearLayout {
        val box = LinearLayout(c)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        val t = text(c, "$label ${fmt(start)}", 13f, false, MR.attr.colorOnSurfaceVariant)
        val s = Slider(c)
        s.valueFrom = min; s.valueTo = max
        s.value = start.coerceIn(min, max)
        s.addOnChangeListener { _, v, _ -> t.text = "$label ${fmt(v)}"; onChange(v) }
        s.addOnSliderTouchListener(object : Slider.OnSliderTouchListener {
            override fun onStartTrackingTouch(slider: Slider) {}
            override fun onStopTrackingTouch(slider: Slider) { onDone() }
        })
        box.addView(t, LinearLayout.LayoutParams(dp(c, 112), -2))
        box.addView(s, LinearLayout.LayoutParams(0, -2, 1f))
        box.layoutParams = lp(c)
        return box
    }

    fun field(c: Context, hint: String, value: String, cb: (String) -> Unit): EditText {
        val e = EditText(c)
        e.setText(value); e.hint = hint; e.setSingleLine(); e.textSize = 14f
        e.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { cb(s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, d: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, d: Int) {}
        })
        e.layoutParams = lp(c, 2)
        return e
    }

    fun keyRow(c: Context, label: String, keys: List<Int>, current: Int, cb: (Int) -> Unit): LinearLayout {
        val box = LinearLayout(c)
        box.orientation = LinearLayout.HORIZONTAL
        box.gravity = Gravity.CENTER_VERTICAL
        box.addView(text(c, label, 13f, false, MR.attr.colorOnSurfaceVariant), LinearLayout.LayoutParams(dp(c, 112), -2))
        val sp = Spinner(c)
        sp.adapter = ArrayAdapter(c, android.R.layout.simple_spinner_dropdown_item, keys.map { keyName(it) })
        sp.setSelection(keys.indexOf(current).coerceAtLeast(0))
        var cur = current
        sp.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                if (keys[pos] != cur) { cur = keys[pos]; cb(cur) }
            }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
        box.addView(sp, LinearLayout.LayoutParams(0, -2, 1f))
        box.layoutParams = lp(c)
        return box
    }

    private fun swatch(c: Context, color: Int, sizeDp: Int): GradientDrawable {
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(color)
        g.setStroke(dp(c, 2), col(c, MR.attr.colorOutline))
        g.setSize(dp(c, sizeDp), dp(c, sizeDp))
        return g
    }

    fun colorRow(c: Context, label: String, start: Int, cb: (Int) -> Unit): LinearLayout {
        val row = LinearLayout(c)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, dp(c, 3), 0, dp(c, 3))
        var cur = start
        val dot = View(c)
        dot.background = swatch(c, cur, 26)
        row.addView(dot, LinearLayout.LayoutParams(dp(c, 26), dp(c, 26)).apply { rightMargin = dp(c, 12) })
        row.addView(text(c, label, 14f), LinearLayout.LayoutParams(0, -2, 1f))
        row.setOnClickListener {
            pickColor(c, cur) { n -> cur = n; dot.background = swatch(c, n, 26); cb(n) }
        }
        row.layoutParams = lp(c)
        return row
    }

    fun pickColor(c: Context, start: Int, cb: (Int) -> Unit) {
        val palette = longArrayOf(0xFFFFFFFF, 0xFF000000, 0xFFF44336, 0xFFE91E63, 0xFF9C27B0, 0xFF673AB7, 0xFF3F51B5,
            0xFF2196F3, 0xFF03A9F4, 0xFF00BCD4, 0xFF009688, 0xFF4CAF50, 0xFF8BC34A, 0xFFFFEB3B, 0xFFFF9800, 0xFF795548)
        var cur = start
        val box = vbox(c, 20)
        val preview = View(c)
        preview.background = swatch(c, cur, 56)
        box.addView(preview, LinearLayout.LayoutParams(dp(c, 56), dp(c, 56)).apply { bottomMargin = dp(c, 12) })
        val hex = EditText(c)
        fun refresh(updateHex: Boolean) {
            preview.background = swatch(c, cur, 56)
            if (updateHex) hex.setText(String.format("#%06X", cur and 0xFFFFFF))
        }
        val grid = GridLayout(c)
        grid.columnCount = 8
        for (p in palette) {
            val v = View(c)
            v.background = swatch(c, p.toInt(), 30)
            v.setOnClickListener { cur = (cur and 0xFF000000.toInt()) or (p.toInt() and 0xFFFFFF); refresh(true) }
            val lp = GridLayout.LayoutParams()
            lp.width = dp(c, 34); lp.height = dp(c, 34); lp.setMargins(dp(c, 2), dp(c, 2), dp(c, 2), dp(c, 2))
            grid.addView(v, lp)
        }
        box.addView(grid)
        box.addView(text(c, "Hex color", 14f, false, MR.attr.colorOnSurfaceVariant))
        hex.setSingleLine()
        hex.setText(String.format("#%06X", cur and 0xFFFFFF))
        hex.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) {
                try { cur = (cur and 0xFF000000.toInt()) or (Color.parseColor(s.toString()) and 0xFFFFFF); refresh(false) } catch (_: Exception) {}
            }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, d: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, d: Int) {}
        })
        box.addView(hex)
        box.addView(sliderRow(c, "Opacity", 0f, 255f, Color.alpha(cur).toFloat(), { "${(it / 2.55f).toInt()}%" }, { v ->
            cur = (v.toInt() shl 24) or (cur and 0xFFFFFF); refresh(false)
        }))
        MaterialAlertDialogBuilder(c).setTitle("Pick a color").setView(box)
            .setPositiveButton("OK") { _, _ -> cb(cur) }
            .setNegativeButton("Cancel", null).show()
    }
}
