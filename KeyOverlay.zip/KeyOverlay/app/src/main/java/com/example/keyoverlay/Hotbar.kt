package com.example.keyoverlay

import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject

/** Hotbar layer: its own layout, style and key bindings, stored separately from the normal buttons. */
class Hotbar {
    var enabled = true
    var slots = 9
    val keys: MutableList<Int> = MutableList(9) { KeyEvent.KEYCODE_1 + it }
    var x = 0.5f
    var y = 0.9f
    var size = 0.095f          // slot size, fraction of screen height
    var gap = 0.12f            // gap, fraction of slot size
    var vertical = false
    var shape = 1              // 0 circle, 1 rounded square, 2 pill
    var corner = 0.2f
    var fill = DEF_FILL
    var stroke = DEF_STROKE
    var selFill = DEF_ON
    var strokeW = 1.5f
    var alpha = 1f
    var showKeys = false       // label slots with the key name instead of 1..9

    /** Slot buttons with positions as fractions of the screen (used for drawing and hit-testing). */
    fun build(w: Float, h: Float): List<Btn> {
        val n = slots.coerceIn(1, 9)
        val d = size * h
        val g = d * gap
        val total = n * d + (n - 1) * g
        return List(n) { i ->
            val off = -total / 2f + d / 2f + i * (d + g)
            val cx = if (vertical) x * w else x * w + off
            val cy = if (vertical) y * h + off else y * h
            Btn("hb$i", if (showKeys) keyName(keys[i]) else "${i + 1}", keys[i], cx / w, cy / h,
                hf = size, shape = shape, corner = corner, fill = fill, stroke = stroke,
                onFill = selFill, alpha = alpha, strokeW = strokeW)
        }
    }

    fun toJson(): String = JSONObject()
        .put("enabled", enabled).put("slots", slots).put("keys", JSONArray(keys))
        .put("x", x.toDouble()).put("y", y.toDouble()).put("size", size.toDouble()).put("gap", gap.toDouble())
        .put("vertical", vertical).put("shape", shape).put("corner", corner.toDouble())
        .put("fill", fill).put("stroke", stroke).put("selFill", selFill)
        .put("strokeW", strokeW.toDouble()).put("alpha", alpha.toDouble()).put("showKeys", showKeys)
        .toString()

    companion object {
        fun fromJson(s: String?): Hotbar {
            val h = Hotbar()
            if (s == null) return h
            try {
                val o = JSONObject(s)
                h.enabled = o.optBoolean("enabled", true)
                h.slots = o.optInt("slots", 9)
                val a = o.optJSONArray("keys")
                if (a != null) for (i in 0 until minOf(a.length(), 9)) h.keys[i] = a.getInt(i)
                h.x = o.optDouble("x", 0.5).toFloat()
                h.y = o.optDouble("y", 0.9).toFloat()
                h.size = o.optDouble("size", 0.095).toFloat()
                h.gap = o.optDouble("gap", 0.12).toFloat()
                h.vertical = o.optBoolean("vertical", false)
                h.shape = o.optInt("shape", 1)
                h.corner = o.optDouble("corner", 0.2).toFloat()
                h.fill = o.optInt("fill", DEF_FILL)
                h.stroke = o.optInt("stroke", DEF_STROKE)
                h.selFill = o.optInt("selFill", DEF_ON)
                h.strokeW = o.optDouble("strokeW", 1.5).toFloat()
                h.alpha = o.optDouble("alpha", 1.0).toFloat()
                h.showKeys = o.optBoolean("showKeys", false)
            } catch (_: Exception) {}
            return h
        }
    }
}
