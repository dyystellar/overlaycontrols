package com.example.keyoverlay

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.R as MR
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup

/** Separate editor for the hotbar layer (does not touch the normal button layout). */
class HotbarActivity : AppCompatActivity() {
    private lateinit var p: Prefs
    private lateinit var hb: Hotbar
    private lateinit var preview: PreviewView
    private lateinit var content: LinearLayout
    private var tab = 0

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val c: Context = this
        p = Prefs(c); hb = p.hotbar()
        val root = LinearLayout(c)
        root.orientation = LinearLayout.HORIZONTAL
        root.setBackgroundColor(Ui.col(c, MR.attr.colorSurface))
        val left = FrameLayout(c)
        left.setPadding(Ui.dp(c, 12), Ui.dp(c, 12), Ui.dp(c, 6), Ui.dp(c, 12))
        left.setBackgroundColor(Ui.col(c, MR.attr.colorSurfaceContainerLowest))
        preview = PreviewView(c, p.layout(), p)
        preview.hotbar = hb
        preview.onHotbarMoved = { save(); rebuild() }
        left.addView(preview, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        root.addView(left, LinearLayout.LayoutParams(0, -1, 3f))

        val right = Ui.vbox(c, 10)
        right.addView(Ui.text(c, "Hotbar (separate layer)", 15f, true))
        right.addView(toggles(c, arrayOf("Layout", "Style", "Keys"), 0) { tab = it; rebuild() }, Ui.lp(c, 4))
        content = Ui.vbox(c)
        val sv = ScrollView(c)
        sv.addView(content)
        right.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        val acts = LinearLayout(c)
        acts.orientation = LinearLayout.HORIZONTAL
        acts.addView(Ui.tonal(c, "Reset", true) {
            p.resetHotbar(); hb = p.hotbar(); preview.hotbar = hb; preview.invalidate(); rebuild()
        }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = Ui.dp(c, 4) })
        acts.addView(Ui.tonal(c, "Done", true) { finish() }, LinearLayout.LayoutParams(0, -2, 1f))
        right.addView(acts)
        root.addView(right, LinearLayout.LayoutParams(0, -1, 2f))
        setContentView(root)
        rebuild()
    }

    private fun save() { p.saveHotbar(hb) }
    private fun changed() { preview.invalidate(); save() }

    override fun onPause() {
        super.onPause()
        save()
        try { startService(Intent(this, OverlayService::class.java).setAction(OverlayService.A_RELOAD)) } catch (_: Throwable) {}
    }

    private fun toggles(c: Context, names: Array<String>, selected: Int, onPick: (Int) -> Unit): MaterialButtonToggleGroup {
        val g = MaterialButtonToggleGroup(c)
        g.isSingleSelection = true
        g.isSelectionRequired = true
        val ids = IntArray(names.size) { View.generateViewId() }
        for (i in names.indices) {
            val mb = MaterialButton(c, null, MR.attr.materialButtonOutlinedStyle)
            mb.id = ids[i]; mb.text = names[i]; mb.setAllCaps(false)
            g.addView(mb, LinearLayout.LayoutParams(0, -2, 1f))
        }
        g.check(ids[selected.coerceIn(0, names.size - 1)])
        g.addOnButtonCheckedListener { _, id, checked -> if (checked) onPick(ids.indexOf(id)) }
        return g
    }

    private fun rebuild() {
        content.removeAllViews()
        when (tab) { 0 -> tabLayout(); 1 -> tabStyle(); else -> tabKeys() }
    }

    private fun pct(v: Float) = "${v.toInt()}%"

    private fun tabLayout() {
        val c: Context = this
        content.addView(Ui.switchRow(c, "Show hotbar", hb.enabled) { hb.enabled = it; save() })
        content.addView(Ui.sliderRow(c, "Slots", 1f, 9f, hb.slots.toFloat(), { "${it.toInt()}" }, { hb.slots = it.toInt(); preview.invalidate() }, { save() }))
        content.addView(Ui.sliderRow(c, "Size", 4f, 20f, hb.size * 100, { pct(it) }, { hb.size = it / 100f; preview.invalidate() }, { save() }))
        content.addView(Ui.sliderRow(c, "Gap", 0f, 50f, hb.gap * 100, { pct(it) }, { hb.gap = it / 100f; preview.invalidate() }, { save() }))
        content.addView(Ui.sliderRow(c, "Position X", 5f, 95f, hb.x * 100, { pct(it) }, { hb.x = it / 100f; preview.invalidate() }, { save() }))
        content.addView(Ui.sliderRow(c, "Position Y", 5f, 95f, hb.y * 100, { pct(it) }, { hb.y = it / 100f; preview.invalidate() }, { save() }))
        content.addView(Ui.switchRow(c, "Vertical hotbar", hb.vertical) { hb.vertical = it; changed() })
        content.addView(Ui.switchRow(c, "Show key names on slots", hb.showKeys) { hb.showKeys = it; changed() })
        content.addView(Ui.text(c, "Tip: drag in the preview to move the hotbar.", 12f, false, MR.attr.colorOnSurfaceVariant))
    }

    private fun tabStyle() {
        val c: Context = this
        content.addView(toggles(c, arrayOf("Circle", "Rounded", "Pill"), hb.shape) { hb.shape = it; changed() }, Ui.lp(c, 4))
        content.addView(Ui.sliderRow(c, "Corners", 0f, 50f, hb.corner * 100, { pct(it) }, { hb.corner = it / 100f; preview.invalidate() }, { save() }))
        content.addView(Ui.sliderRow(c, "Outline", 0f, 8f, hb.strokeW, { "%.1f".format(it) }, { hb.strokeW = it; preview.invalidate() }, { save() }))
        content.addView(Ui.sliderRow(c, "Opacity", 10f, 100f, hb.alpha * 100, { pct(it) }, { hb.alpha = it / 100f; preview.invalidate() }, { save() }))
        content.addView(Ui.colorRow(c, "Slot color", hb.fill) { hb.fill = it; changed() })
        content.addView(Ui.colorRow(c, "Outline color", hb.stroke) { hb.stroke = it; changed() })
        content.addView(Ui.colorRow(c, "Selected slot color", hb.selFill) { hb.selFill = it; changed() })
    }

    private fun tabKeys() {
        val c: Context = this
        val keys = (keyList() + hb.keys).distinct()
        for (i in 0 until 9) {
            content.addView(Ui.keyRow(c, "Slot ${i + 1}", keys, hb.keys[i]) { hb.keys[i] = it; changed() })
        }
    }
}
