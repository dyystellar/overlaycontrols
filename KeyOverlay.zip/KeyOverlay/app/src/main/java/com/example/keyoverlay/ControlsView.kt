package com.example.keyoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.hypot

class ControlsView(ctx: Context, private val p: Prefs) : View(ctx) {
    var editMode = false
    private val btns = p.layout()
    private val hb = p.hotbar()
    private var slots: List<Btn> = emptyList()
    private val heldSlots = HashMap<Int, Btn>()
    private val density = resources.displayMetrics.density
    private val held = HashMap<Int, Btn>()
    private val drag = HashMap<Int, Btn>()
    private var swipe = -1
    private var lx = 0f; private var ly = 0f; private var t0 = 0L
    private var moved = false; private var holding = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = -1; textAlign = Paint.Align.CENTER; textSize = 16f * density }
    private val holdRun = Runnable {
        if (!moved && swipe != -1) { holding = true; InputInjector.mouseButton(MOUSE_LEFT, true) }
    }

    var passThrough = false
    private val cursorPath = Path().apply {
        moveTo(0f, 0f); lineTo(0f, 17f); lineTo(4.5f, 13f); lineTo(8f, 20f); lineTo(11f, 18.5f); lineTo(7.5f, 12f); lineTo(13f, 12f); close()
    }
    private val curFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = -1 }
    private val curLine = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; color = 0xFF000000.toInt(); strokeWidth = 1.6f; strokeJoin = Paint.Join.ROUND
    }

    /** Visible cursor = touchpad style: swipes move a drawn pointer, taps click where it is. */
    fun refreshCursor() { InputInjector.configure(p.relativeMouse && !p.showCursor); invalidate() }

    init { refreshCursor() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        InputInjector.setScreen(w, h)
        slots = if (hb.enabled && w > 0 && h > 0) hb.build(w.toFloat(), h.toFloat()) else emptyList()
    }

    override fun onDraw(c: Canvas) {
        for (b in btns) {
            if (!b.visible) continue
            val d = ButtonRenderer.diameter(b, height.toFloat(), p.buttonScale, density)
            ButtonRenderer.draw(c, b, b.x * width, b.y * height, d, p.opacity, density)
        }
        for (s in slots) ButtonRenderer.draw(c, s, s.x * width, s.y * height, s.hf * height, 1f, density)
        if (p.showCursor && !passThrough && !editMode) {
            val k = 1.3f * density
            c.save(); c.translate(InputInjector.cursorX(), InputInjector.cursorY()); c.scale(k, k)
            c.drawPath(cursorPath, curFill); c.drawPath(cursorPath, curLine)
            c.restore()
        }
        if (editMode) c.drawText("EDIT MODE - drag buttons", width / 2f, 80f * density, hint)
    }

    private fun hit(x: Float, y: Float) = btns.lastOrNull {
        it.visible && ButtonRenderer.contains(it, x, y, width.toFloat(), height.toFloat(), p.buttonScale, density)
    }

    private fun fireKey(k: Int, down: Boolean) {
        if (k == 0) return
        if (k < 0) InputInjector.mouseButton(k, down) else InputInjector.key(k, down)
    }

    private fun fire(b: Btn, down: Boolean) {
        if (down) { fireKey(b.key, true); fireKey(b.key2, true); fireKey(b.key3, true) }
        else { fireKey(b.key3, false); fireKey(b.key2, false); fireKey(b.key, false) }
    }

    private fun press(b: Btn) {
        if (b.toggle) { b.on = !b.on; fire(b, b.on) } else { b.on = true; fire(b, true) }
        if (p.haptics) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        invalidate()
    }

    private fun release(b: Btn) { if (!b.toggle) { b.on = false; fire(b, false); invalidate() } }

    fun releaseAll() {
        removeCallbacks(holdRun)
        held.values.forEach { release(it) }; held.clear()
        heldSlots.values.forEach { fireKey(it.key, false) }; heldSlots.clear()
        btns.filter { it.toggle && it.on }.forEach { it.on = false; fire(it, false) }
        if (holding) { InputInjector.mouseButton(MOUSE_LEFT, false); holding = false }
        swipe = -1; invalidate()
    }

    private fun down(id: Int, x: Float, y: Float) {
        if (!editMode) {
            val s = slots.firstOrNull { ButtonRenderer.contains(it, x, y, width.toFloat(), height.toFloat(), 1f, density) }
            if (s != null) {
                slots.forEach { it.on = false }
                s.on = true
                heldSlots[id] = s
                fireKey(s.key, true)
                if (p.haptics) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                invalidate()
                return
            }
        }
        val b = hit(x, y)
        if (editMode) { if (b != null) drag[id] = b; return }
        if (b != null) { held[id] = b; press(b) }
        else if (swipe == -1) {
            swipe = id; lx = x; ly = y; t0 = System.currentTimeMillis(); moved = false; holding = false
            postDelayed(holdRun, 350)
        }
    }

    private fun move(id: Int, x: Float, y: Float) {
        drag[id]?.let { it.x = (x / width).coerceIn(0.02f, 0.98f); it.y = (y / height).coerceIn(0.02f, 0.98f); invalidate(); return }
        if (id == swipe) {
            val dx = x - lx; val dy = y - ly
            if (!moved && hypot(x - lx, y - ly) > slop) { moved = true; removeCallbacks(holdRun) }
            if (moved || holding) { InputInjector.move(dx * p.sensitivity, dy * p.sensitivity); lx = x; ly = y; if (p.showCursor) invalidate() }
        }
    }

    private fun up(id: Int) {
        heldSlots.remove(id)?.let { fireKey(it.key, false); return }
        if (drag.remove(id) != null) { p.saveLayout(btns); return }
        held.remove(id)?.let { release(it); return }
        if (id == swipe) {
            removeCallbacks(holdRun)
            if (holding) { InputInjector.mouseButton(MOUSE_LEFT, false); holding = false }
            else if (!moved && p.tapToClick && System.currentTimeMillis() - t0 < 350) {
                InputInjector.mouseButton(MOUSE_LEFT, true); InputInjector.mouseButton(MOUSE_LEFT, false)
            }
            swipe = -1
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex; down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> releaseAll()
        }
        return true
    }
}
