package com.example.keyoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.hypot

class ControlsView(ctx: Context, private val p: Prefs) : View(ctx) {
    var editMode = false
    private val btns = p.layout()
    private val density = resources.displayMetrics.density
    private val held = HashMap<Int, Btn>()
    private val drag = HashMap<Int, Btn>()
    private var swipe = -1
    private var lx = 0f; private var ly = 0f; private var t0 = 0L
    private var moved = false; private var holding = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = -1; textAlign = Paint.Align.CENTER; textSize = 16f * density }
    private val holdRun = Runnable {
        if (!moved && swipe != -1) { holding = true; InputInjector.mouseButton(MOUSE_LEFT, true) }
    }

    init { InputInjector.configure(p.relativeMouse) }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { InputInjector.setScreen(w, h) }

    override fun onDraw(c: Canvas) {
        for (b in btns) {
            if (!b.visible) continue
            val d = ButtonRenderer.diameter(b, height.toFloat(), p.buttonScale, density)
            ButtonRenderer.draw(c, b, b.x * width, b.y * height, d, p.opacity, density)
        }
        if (editMode) c.drawText("EDIT MODE - drag buttons", width / 2f, 80f * density, hint)
    }

    private fun hit(x: Float, y: Float) = btns.lastOrNull {
        it.visible && ButtonRenderer.contains(it, x, y, width.toFloat(), height.toFloat(), p.buttonScale, density)
    }

    private fun fireKey(k: Int, down: Boolean) {
        if (k == 0) return
        if (k < 0) InputInjector.mouseButton(k, down) else InputInjector.key(k, down)
    }

    private fun fire(b: Btn, down: Boolean) {
        if (down) { fireKey(b.key, true); fireKey(b.key2, true); fireKey(b.key3, true) }
        else { fireKey(b.key3, false); fireKey(b.key2, false); fireKey(b.key, false) }
    }

    private fun press(b: Btn) {
        if (b.toggle) { b.on = !b.on; fire(b, b.on) } else { b.on = true; fire(b, true) }
        if (p.haptics) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        invalidate()
    }

    private fun release(b: Btn) { if (!b.toggle) { b.on = false; fire(b, false); invalidate() } }

    fun releaseAll() {
        removeCallbacks(holdRun)
        held.values.forEach { release(it) }; held.clear()
        btns.filter { it.toggle && it.on }.forEach { it.on = false; fire(it, false) }
        if (holding) { InputInjector.mouseButton(MOUSE_LEFT, false); holding = false }
        swipe = -1; invalidate()
    }

    private fun down(id: Int, x: Float, y: Float) {
        val b = hit(x, y)
        if (editMode) { if (b != null) drag[id] = b; return }
        if (b != null) { held[id] = b; press(b) }
        else if (swipe == -1) {
            swipe = id; lx = x; ly = y; t0 = System.currentTimeMillis(); moved = false; holding = false
            postDelayed(holdRun, 350)
        }
    }

    private fun move(id: Int, x: Float, y: Float) {
        drag[id]?.let { it.x = (x / width).coerceIn(0.02f, 0.98f); it.y = (y / height).coerceIn(0.02f, 0.98f); invalidate(); return }
        if (id == swipe) {
            val dx = x - lx; val dy = y - ly
            if (!moved && hypot(x - lx, y - ly) > slop) { moved = true; removeCallbacks(holdRun) }
            if (moved || holding) { InputInjector.move(dx * p.sensitivity, dy * p.sensitivity); lx = x; ly = y }
        }
    }

    private fun up(id: Int) {
        if (drag.remove(id) != null) { p.saveLayout(btns); return }
        held.remove(id)?.let { release(it); return }
        if (id == swipe) {
            removeCallbacks(holdRun)
            if (holding) { InputInjector.mouseButton(MOUSE_LEFT, false); holding = false }
            else if (!moved && p.tapToClick && System.currentTimeMillis() - t0 < 350) {
                InputInjector.mouseButton(MOUSE_LEFT, true); InputInjector.mouseButton(MOUSE_LEFT, false)
            }
            swipe = -1
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex; down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> releaseAll()
        }
        return true
    }
}
