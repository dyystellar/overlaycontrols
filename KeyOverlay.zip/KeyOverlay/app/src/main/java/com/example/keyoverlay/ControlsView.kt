package com.example.keyoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.hypot

class ControlsView(ctx: Context, private val p: Prefs) : View(ctx) {
    var editMode = false
    private val btns = p.layout()
    private val held = HashMap<Int, Btn>()
    private val drag = HashMap<Int, Btn>()
    private var swipe = -1
    private var lx = 0f; private var ly = 0f; private var t0 = 0L
    private var moved = false; private var holding = false
    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFFFFFFFF.toInt() }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); textAlign = Paint.Align.CENTER }
    private val holdRun = Runnable {
        if (!moved && swipe != -1) { holding = true; InputInjector.mouseButton(MOUSE_LEFT, true) }
    }

    init { InputInjector.configure(p.relativeMouse) }

    private fun dp(v: Float) = v * resources.displayMetrics.density
    private fun radius(b: Btn) = dp(30f) * b.size * p.buttonScale

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) { InputInjector.setScreen(w, h) }

    override fun onDraw(c: Canvas) {
        stroke.strokeWidth = dp(2f)
        for (b in btns) {
            if (!b.visible) continue
            val x = b.x * width; val y = b.y * height; val r = radius(b)
            fill.color = 0xFFFFFFFF.toInt()
            fill.alpha = ((if (b.on) 0.75f else 0.3f) * p.opacity * 255).toInt()
            c.drawCircle(x, y, r, fill)
            stroke.alpha = (p.opacity * 255).toInt()
            c.drawCircle(x, y, r, stroke)
            text.textSize = r * 0.5f; text.alpha = (p.opacity * 255).toInt().coerceAtLeast(120)
            c.drawText(b.label, x, y + text.textSize / 3, text)
        }
        if (editMode) { text.textSize = dp(16f); text.alpha = 255; c.drawText("EDIT MODE - drag buttons", width / 2f, dp(80f), text) }
    }

    private fun hit(x: Float, y: Float) =
        btns.lastOrNull { it.visible && hypot(x - it.x * width, y - it.y * height) <= radius(it) * 1.15f }

    private fun fire(b: Btn, down: Boolean) {
        if (b.key < 0) InputInjector.mouseButton(b.key, down) else InputInjector.key(b.key, down)
    }

    private fun press(b: Btn) {
        if (b.toggle) { b.on = !b.on; fire(b, b.on) } else { b.on = true; fire(b, true) }
        if (p.haptics) performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        invalidate()
    }

    private fun release(b: Btn) { if (!b.toggle) { b.on = false; fire(b, false); invalidate() } }

    fun releaseAll() {
        removeCallbacks(holdRun)
        held.values.forEach { release(it) }; held.clear()
        btns.filter { it.toggle && it.on }.forEach { it.on = false; fire(it, false) }
        if (holding) { InputInjector.mouseButton(MOUSE_LEFT, false); holding = false }
        swipe = -1; invalidate()
    }

    private fun down(id: Int, x: Float, y: Float) {
        val b = hit(x, y)
        if (editMode) { if (b != null) drag[id] = b; return }
        if (b != null) { held[id] = b; press(b) }
        else if (swipe == -1) {
            swipe = id; lx = x; ly = y; t0 = System.currentTimeMillis(); moved = false; holding = false
            postDelayed(holdRun, 350)
        }
    }

    private fun move(id: Int, x: Float, y: Float) {
        drag[id]?.let { it.x = (x / width).coerceIn(0.02f, 0.98f); it.y = (y / height).coerceIn(0.02f, 0.98f); invalidate(); return }
        if (id == swipe) {
            val dx = x - lx; val dy = y - ly
            if (!moved && hypot(x - lx, y - ly) > slop) { moved = true; removeCallbacks(holdRun) }
            if (moved || holding) { InputInjector.move(dx * p.sensitivity, dy * p.sensitivity); lx = x; ly = y }
        }
    }

    private fun up(id: Int) {
        if (drag.remove(id) != null) { p.saveLayout(btns); return }
        held.remove(id)?.let { release(it); return }
        if (id == swipe) {
            removeCallbacks(holdRun)
            if (holding) { InputInjector.mouseButton(MOUSE_LEFT, false); holding = false }
            else if (!moved && p.tapToClick && System.currentTimeMillis() - t0 < 350) {
                InputInjector.mouseButton(MOUSE_LEFT, true); InputInjector.mouseButton(MOUSE_LEFT, false)
            }
            swipe = -1
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_POINTER_DOWN -> {
                val i = e.actionIndex; down(e.getPointerId(i), e.getX(i), e.getY(i))
            }
            MotionEvent.ACTION_MOVE -> for (i in 0 until e.pointerCount) move(e.getPointerId(i), e.getX(i), e.getY(i))
            MotionEvent.ACTION_UP, MotionEvent.ACTION_POINTER_UP -> up(e.getPointerId(e.actionIndex))
            MotionEvent.ACTION_CANCEL -> releaseAll()
        }
        return true
    }
}
