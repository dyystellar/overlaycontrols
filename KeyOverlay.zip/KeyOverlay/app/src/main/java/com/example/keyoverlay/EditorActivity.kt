package com.example.keyoverlay

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.View.MeasureSpec
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.R as MR
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup

class PreviewView(ctx: Context, private val list: MutableList<Btn>, private val p: Prefs) : View(ctx) {
    var selected: Btn? = null
    var onSelect: ((Btn?) -> Unit)? = null
    var onChanged: (() -> Unit)? = null
    private var dragging: Btn? = null
    private val dm = resources.displayMetrics
    private val aspect = maxOf(dm.widthPixels, dm.heightPixels).toFloat() / minOf(dm.widthPixels, dm.heightPixels)
    private val realH = minOf(dm.widthPixels, dm.heightPixels).toFloat()
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun dens() = dm.density * (height / realH)

    override fun onMeasure(w: Int, h: Int) {
        val aw = MeasureSpec.getSize(w).toFloat(); val ah = MeasureSpec.getSize(h).toFloat()
        var ww = aw; var hh = aw / aspect
        if (hh > ah) { hh = ah; ww = ah * aspect }
        setMeasuredDimension(ww.toInt(), hh.toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        bg.shader = LinearGradient(0f, 0f, 0f, h.toFloat(),
            intArrayOf(0xFF7EC8EE.toInt(), 0xFFB9E4F5.toInt(), 0xFF5E8F3A.toInt(), 0xFF3D6B26.toInt()),
            floatArrayOf(0f, .5f, .52f, 1f), Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val r = 24f * dm.density
        c.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, bg)
        val k = dens()
        for (b in list) {
            val d = ButtonRenderer.diameter(b, height.toFloat(), p.buttonScale, k)
            val ga = if (b.visible) p.opacity else p.opacity * 0.35f
            ButtonRenderer.draw(c, b, b.x * width, b.y * height, d, ga, k)
            if (b === selected) ButtonRenderer.drawSelection(c, b, b.x * width, b.y * height, d, k)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val hit = list.lastOrNull { ButtonRenderer.contains(it, e.x, e.y, width.toFloat(), height.toFloat(), p.buttonScale, dens()) }
                if (hit != null) { dragging = hit; selected = hit; onSelect?.invoke(hit); invalidate() }
            }
            MotionEvent.ACTION_MOVE -> dragging?.let {
                it.x = (e.x / width).coerceIn(0.01f, 0.99f); it.y = (e.y / height).coerceIn(0.01f, 0.99f); invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { if (dragging != null) onChanged?.invoke(); dragging = null }
        }
        return true
    }
}

class EditorActivity : AppCompatActivity() {
    private lateinit var p: Prefs
    private lateinit var list: MutableList<Btn>
    private lateinit var preview: PreviewView
    private lateinit var panel: LinearLayout
    private var sel: Btn? = null

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val c: Context = this
        p = Prefs(c); list = p.layout()
        val root = LinearLayout(c)
        root.orientation = LinearLayout.HORIZONTAL
        root.setBackgroundColor(Ui.col(c, MR.attr.colorSurface))
        val left = FrameLayout(c)
        left.setPadding(Ui.dp(c, 16), Ui.dp(c, 16), Ui.dp(c, 8), Ui.dp(c, 16))
        left.setBackgroundColor(Ui.col(c, MR.attr.colorSurfaceContainerLowest))
        preview = PreviewView(c, list, p)
        preview.onSelect = { sel = it; rebuild() }
        preview.onChanged = { save() }
        left.addView(preview, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        root.addView(left, LinearLayout.LayoutParams(0, -1, 3f))
        val scroll = ScrollView(c)
        panel = Ui.vbox(c, 16)
        scroll.addView(panel)
        root.addView(scroll, LinearLayout.LayoutParams(0, -1, 2f))
        setContentView(root)
        sel = list.firstOrNull(); preview.selected = sel
        rebuild()
    }

    private fun save() { p.saveLayout(list) }

    override fun onPause() {
        super.onPause()
        save()
        try { startService(Intent(this, OverlayService::class.java).setAction(OverlayService.A_RELOAD)) } catch (_: Throwable) {}
    }

    private fun select(b: Btn?) { sel = b; preview.selected = b; preview.invalidate(); rebuild() }

    private fun rebuild() {
        val c: Context = this
        panel.removeAllViews()
        panel.addView(Ui.text(c, "Button editor", 28f, true))
        val hint = Ui.text(c, "Tap a button to edit it. Drag to move.", 13f, false, MR.attr.colorOnSurfaceVariant)
        hint.setPadding(0, 0, 0, Ui.dp(c, 12))
        panel.addView(hint)
        val top = LinearLayout(c)
        top.orientation = LinearLayout.HORIZONTAL
        top.addView(Ui.filled(c, "Add button") { addButton() }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = Ui.dp(c, 8) })
        top.addView(Ui.tonal(c, "Done") { finish() }, LinearLayout.LayoutParams(0, -2, 1f))
        panel.addView(top, Ui.lp(c, 8))

        val s = sel
        if (s == null) {
            panel.addView(Ui.text(c, "No button selected.", 16f))
            return
        }
        val keys = (keyList() + list.map { it.key }).distinct()
        val keysNone = (listOf(0) + keys + list.map { it.key2 }).distinct()
        val (card, box) = Ui.section(c, "Selected: ${s.label}")

        box.addView(Ui.field(c, "Label", s.label) { s.label = it; preview.invalidate(); save() })
        box.addView(Ui.keyRow(c, "Key", keys, s.key) { s.key = it; save() })
        box.addView(Ui.keyRow(c, "Extra key (pressed together)", keysNone, s.key2) { s.key2 = it; save() })

        box.addView(Ui.text(c, "Shape", 14f, false, MR.attr.colorOnSurfaceVariant))
        val group = MaterialButtonToggleGroup(c)
        group.isSingleSelection = true
        group.isSelectionRequired = true
        val ids = IntArray(3) { View.generateViewId() }
        val names = arrayOf("Circle", "Rounded", "Pill")
        for (i in 0..2) {
            val mb = MaterialButton(c, null, MR.attr.materialButtonOutlinedStyle)
            mb.id = ids[i]; mb.text = names[i]; mb.setAllCaps(false)
            group.addView(mb, LinearLayout.LayoutParams(0, -2, 1f))
        }
        group.check(ids[s.shape.coerceIn(0, 2)])
        group.addOnButtonCheckedListener { _, id, checked ->
            if (checked) { s.shape = ids.indexOf(id); preview.invalidate(); save() }
        }
        box.addView(group, Ui.lp(c, 8))

        box.addView(Ui.sliderRow(c, "Size", 3f, 40f, s.hf * 100, { "${it.toInt()}%" }, { s.hf = it / 100f; preview.invalidate() }, { save() }))
        box.addView(Ui.sliderRow(c, "Width", 50f, 300f, s.wr * 100, { "${it.toInt()}%" }, { s.wr = it / 100f; preview.invalidate() }, { save() }))
        box.addView(Ui.sliderRow(c, "Opacity", 10f, 100f, s.alpha * 100, { "${it.toInt()}%" }, { s.alpha = it / 100f; preview.invalidate() }, { save() }))
        box.addView(Ui.sliderRow(c, "Outline width", 0f, 8f, s.strokeW, { "%.1f".format(it) }, { s.strokeW = it; preview.invalidate() }, { save() }))
        box.addView(Ui.sliderRow(c, "Corner roundness (rounded shape)", 0f, 50f, s.corner * 100, { "${it.toInt()}%" }, { s.corner = it / 100f; preview.invalidate() }, { save() }))

        box.addView(Ui.colorRow(c, "Fill color", s.fill) { s.fill = it; preview.invalidate(); save() })
        box.addView(Ui.colorRow(c, "Outline color", s.stroke) { s.stroke = it; preview.invalidate(); save() })
        box.addView(Ui.colorRow(c, "Pressed color", s.onFill) { s.onFill = it; save() })

        box.addView(Ui.switchRow(c, "Toggle (tap to hold, tap again to release)", s.toggle) { s.toggle = it; save() })
        box.addView(Ui.switchRow(c, "Show in game", s.visible) { s.visible = it; preview.invalidate(); save() })
        panel.addView(card)

        val acts = LinearLayout(c)
        acts.orientation = LinearLayout.HORIZONTAL
        acts.addView(Ui.tonal(c, "Duplicate") { duplicate(s) }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = Ui.dp(c, 8) })
        acts.addView(Ui.tonal(c, "Delete") { delete(s) }, LinearLayout.LayoutParams(0, -2, 1f))
        panel.addView(acts, Ui.lp(c, 8))
        panel.addView(Ui.tonal(c, "Apply this look to all buttons") { applyToAll(s) })
    }

    private fun addButton() {
        val n = Btn("n${System.nanoTime()}", "NEW", android.view.KeyEvent.KEYCODE_F, 0.5f, 0.5f, hf = 0.12f)
        list.add(n); save(); select(n)
    }

    private fun duplicate(s: Btn) {
        val n = s.copy(id = "d${System.nanoTime()}", x = (s.x + 0.04f).coerceAtMost(0.97f), y = (s.y + 0.04f).coerceAtMost(0.97f))
        list.add(n); save(); select(n)
    }

    private fun delete(s: Btn) { list.remove(s); save(); select(list.lastOrNull()) }

    private fun applyToAll(s: Btn) {
        for (o in list) {
            o.shape = s.shape; o.fill = s.fill; o.stroke = s.stroke; o.onFill = s.onFill
            o.alpha = s.alpha; o.strokeW = s.strokeW; o.corner = s.corner
        }
        save(); preview.invalidate()
    }
}
