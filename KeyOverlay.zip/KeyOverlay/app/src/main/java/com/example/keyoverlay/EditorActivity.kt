package com.example.keyoverlay

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.View.MeasureSpec
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.R as MR
import com.google.android.material.button.MaterialButton
import com.google.android.material.button.MaterialButtonToggleGroup

class PreviewView(ctx: Context, private val list: MutableList<Btn>, private val p: Prefs) : View(ctx) {
    var selected: Btn? = null
    var onSelect: ((Btn?) -> Unit)? = null
    var onChanged: (() -> Unit)? = null
    var hotbar: Hotbar? = null
    var onHotbarMoved: (() -> Unit)? = null
    private var dragging: Btn? = null
    private val dm = resources.displayMetrics
    private val aspect = maxOf(dm.widthPixels, dm.heightPixels).toFloat() / minOf(dm.widthPixels, dm.heightPixels)
    private val realH = minOf(dm.widthPixels, dm.heightPixels).toFloat()
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun dens() = dm.density * (height / realH)

    override fun onMeasure(w: Int, h: Int) {
        val aw = MeasureSpec.getSize(w).toFloat(); val ah = MeasureSpec.getSize(h).toFloat()
        var ww = aw; var hh = aw / aspect
        if (hh > ah) { hh = ah; ww = ah * aspect }
        setMeasuredDimension(ww.toInt(), hh.toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        bg.shader = LinearGradient(0f, 0f, 0f, h.toFloat(),
            intArrayOf(0xFF7EC8EE.toInt(), 0xFFB9E4F5.toInt(), 0xFF5E8F3A.toInt(), 0xFF3D6B26.toInt()),
            floatArrayOf(0f, .5f, .52f, 1f), Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val r = 24f * dm.density
        c.drawRoundRect(0f, 0f, width.toFloat(), height.toFloat(), r, r, bg)
        val k = dens()
        for (b in list) {
            val d = ButtonRenderer.diameter(b, height.toFloat(), p.buttonScale, k)
            val ga = if (hotbar != null) p.opacity * 0.3f else if (b.visible) p.opacity else p.opacity * 0.35f
            ButtonRenderer.draw(c, b, b.x * width, b.y * height, d, ga, k)
            if (b === selected && hotbar == null) ButtonRenderer.drawSelection(c, b, b.x * width, b.y * height, d, k)
        }
        hotbar?.let { h ->
            if (width > 0) h.build(width.toFloat(), height.toFloat()).forEachIndexed { i, s ->
                s.on = i == 0
                ButtonRenderer.draw(c, s, s.x * width, s.y * height, s.hf * height, 1f, k)
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val hbar = hotbar
        if (hbar != null) {
            if (e.actionMasked == MotionEvent.ACTION_DOWN || e.actionMasked == MotionEvent.ACTION_MOVE) {
                hbar.x = (e.x / width).coerceIn(0.05f, 0.95f); hbar.y = (e.y / height).coerceIn(0.05f, 0.95f); invalidate()
            } else if (e.actionMasked == MotionEvent.ACTION_UP) onHotbarMoved?.invoke()
            return true
        }
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val hit = list.lastOrNull { ButtonRenderer.contains(it, e.x, e.y, width.toFloat(), height.toFloat(), p.buttonScale, dens()) }
                if (hit != null) { dragging = hit; selected = hit; onSelect?.invoke(hit); invalidate() }
            }
            MotionEvent.ACTION_MOVE -> dragging?.let {
                it.x = (e.x / width).coerceIn(0.01f, 0.99f); it.y = (e.y / height).coerceIn(0.01f, 0.99f); invalidate()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { if (dragging != null) onChanged?.invoke(); dragging = null }
        }
        return true
    }
}

class EditorActivity : AppCompatActivity() {
    private lateinit var p: Prefs
    private lateinit var list: MutableList<Btn>
    private lateinit var preview: PreviewView
    private lateinit var content: LinearLayout
    private lateinit var title: TextView
    private var sel: Btn? = null
    private var tab = 0
    private var applyAll = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val c: Context = this
        p = Prefs(c); list = p.layout()
        val root = LinearLayout(c)
        root.orientation = LinearLayout.HORIZONTAL
        root.setBackgroundColor(Ui.col(c, MR.attr.colorSurface))
        val left = FrameLayout(c)
        left.setPadding(Ui.dp(c, 12), Ui.dp(c, 12), Ui.dp(c, 6), Ui.dp(c, 12))
        left.setBackgroundColor(Ui.col(c, MR.attr.colorSurfaceContainerLowest))
        preview = PreviewView(c, list, p)
        preview.onSelect = { sel = it; rebuild() }
        preview.onChanged = { save() }
        left.addView(preview, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER))
        root.addView(left, LinearLayout.LayoutParams(0, -1, 3f))

        val right = Ui.vbox(c, 10)
        title = Ui.text(c, "", 15f, true)
        right.addView(title)
        right.addView(Ui.switchRow(c, "Apply style changes to ALL buttons", false) { applyAll = it; rebuild() })
        val tabs = MaterialButtonToggleGroup(c)
        tabs.isSingleSelection = true
        tabs.isSelectionRequired = true
        val tids = IntArray(3) { View.generateViewId() }
        val tnames = arrayOf("Button", "Shape", "Colors")
        for (i in 0..2) {
            val mb = MaterialButton(c, null, MR.attr.materialButtonOutlinedStyle)
            mb.id = tids[i]; mb.text = tnames[i]; mb.setAllCaps(false)
            tabs.addView(mb, LinearLayout.LayoutParams(0, -2, 1f))
        }
        tabs.check(tids[0])
        tabs.addOnButtonCheckedListener { _, id, checked -> if (checked) { tab = tids.indexOf(id); rebuild() } }
        right.addView(tabs, Ui.lp(c, 4))
        content = Ui.vbox(c)
        val sv = ScrollView(c)
        sv.addView(content)
        right.addView(sv, LinearLayout.LayoutParams(-1, 0, 1f))
        val acts = LinearLayout(c)
        acts.orientation = LinearLayout.HORIZONTAL
        fun act(label: String, cb: () -> Unit) {
            acts.addView(Ui.tonal(c, label, true, cb), LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = Ui.dp(c, 4) })
        }
        act("Add") { addButton() }
        act("Copy") { sel?.let { duplicate(it) } }
        act("Delete") { sel?.let { delete(it) } }
        act("Done") { finish() }
        right.addView(acts)
        root.addView(right, LinearLayout.LayoutParams(0, -1, 2f))
        setContentView(root)
        sel = list.firstOrNull(); preview.selected = sel
        rebuild()
    }

    private fun save() { p.saveLayout(list) }
    private fun changed() { preview.invalidate(); save() }

    override fun onPause() {
        super.onPause()
        save()
        try { startService(Intent(this, OverlayService::class.java).setAction(OverlayService.A_RELOAD)) } catch (_: Throwable) {}
    }

    private fun select(b: Btn?) { sel = b; preview.selected = b; preview.invalidate(); rebuild() }

    /** Applies a style change to every button when "ALL" is on, otherwise only to the selected one. */
    private fun each(f: (Btn) -> Unit) { if (applyAll) list.forEach(f) else sel?.let(f) }

    private fun rebuild() {
        content.removeAllViews()
        val s = sel
        title.text = if (applyAll) "Style changes affect ALL buttons" else if (s != null) "Selected: ${s.label}" else "Tap a button to edit it"
        if (s == null) return
        when (tab) { 0 -> tabButton(s); 1 -> tabShape(s); else -> tabColors(s) }
    }

    private fun tabButton(s: Btn) {
        val c: Context = this
        val keys = (keyList() + list.map { it.key }).distinct()
        val keysNone = (listOf(0) + keys + list.map { it.key2 }).distinct()
        content.addView(Ui.field(c, "Label", s.label) { s.label = it; changed() })
        content.addView(Ui.keyRow(c, "Key", keys, s.key) { s.key = it; save() })
        content.addView(Ui.keyRow(c, "Extra key", keysNone, s.key2) { s.key2 = it; save() })
        content.addView(Ui.switchRow(c, "Toggle (tap on / tap off)", s.toggle) { s.toggle = it; save() })
        content.addView(Ui.switchRow(c, "Show in game", s.visible) { s.visible = it; changed() })
    }

    private fun tabShape(s: Btn) {
        val c: Context = this
        val group = MaterialButtonToggleGroup(c)
        group.isSingleSelection = true
        group.isSelectionRequired = true
        val ids = IntArray(3) { View.generateViewId() }
        val names = arrayOf("Circle", "Rounded", "Pill")
        for (i in 0..2) {
            val mb = MaterialButton(c, null, MR.attr.materialButtonOutlinedStyle)
            mb.id = ids[i]; mb.text = names[i]; mb.setAllCaps(false)
            group.addView(mb, LinearLayout.LayoutParams(0, -2, 1f))
        }
        group.check(ids[s.shape.coerceIn(0, 2)])
        group.addOnButtonCheckedListener { _, id, checked ->
            if (checked) { val sh = ids.indexOf(id); each { b -> b.shape = sh }; changed() }
        }
        content.addView(group, Ui.lp(c, 4))
        content.addView(Ui.sliderRow(c, "Size", 3f, 40f, s.hf * 100, { "${it.toInt()}%" }, { s.hf = it / 100f; preview.invalidate() }, { save() }))
        content.addView(Ui.sliderRow(c, "Width", 50f, 300f, s.wr * 100, { "${it.toInt()}%" }, { s.wr = it / 100f; preview.invalidate() }, { save() }))
        content.addView(Ui.sliderRow(c, "Opacity", 10f, 100f, s.alpha * 100, { "${it.toInt()}%" }, { v -> each { b -> b.alpha = v / 100f }; preview.invalidate() }, { save() }))
        content.addView(Ui.sliderRow(c, "Outline", 0f, 8f, s.strokeW, { "%.1f".format(it) }, { v -> each { b -> b.strokeW = v }; preview.invalidate() }, { save() }))
        content.addView(Ui.sliderRow(c, "Corners", 0f, 50f, s.corner * 100, { "${it.toInt()}%" }, { v -> each { b -> b.corner = v / 100f }; preview.invalidate() }, { save() }))
    }

    private fun tabColors(s: Btn) {
        val c: Context = this
        content.addView(Ui.colorRow(c, "Fill color", s.fill) { v -> each { b -> b.fill = v }; changed() })
        content.addView(Ui.colorRow(c, "Outline color", s.stroke) { v -> each { b -> b.stroke = v }; changed() })
        content.addView(Ui.colorRow(c, "Pressed color", s.onFill) { v -> each { b -> b.onFill = v }; changed() })
    }

    private fun addButton() {
        val n = Btn("n${System.nanoTime()}", "NEW", android.view.KeyEvent.KEYCODE_F, 0.5f, 0.5f, hf = 0.12f)
        list.add(n); save(); select(n)
    }

    private fun duplicate(s: Btn) {
        val n = s.copy(id = "d${System.nanoTime()}", x = (s.x + 0.04f).coerceAtMost(0.97f), y = (s.y + 0.04f).coerceAtMost(0.97f))
        list.add(n); save(); select(n)
    }

    private fun delete(s: Btn) { list.remove(s); save(); select(list.lastOrNull()) }
}
