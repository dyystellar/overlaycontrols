package com.example.keyoverlay

import android.app.Application
import android.content.Context
import com.google.android.material.color.DynamicColors
import org.lsposed.hiddenapibypass.HiddenApiBypass

class App : Application() {
    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(base)
        try { HiddenApiBypass.addHiddenApiExemptions("") } catch (_: Throwable) {}
    }

    override fun onCreate() {
        super.onCreate()
        DynamicColors.applyToActivitiesIfAvailable(this)
    }
}
