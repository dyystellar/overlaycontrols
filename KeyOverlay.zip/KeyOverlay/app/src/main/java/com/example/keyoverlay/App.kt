package com.example.keyoverlay

import android.app.Application
import android.content.Context
import org.lsposed.hiddenapibypass.HiddenApiBypass

class App : Application() {
    override fun attachBaseContext(base: Context?) {
        super.attachBaseContext(base)
        try { HiddenApiBypass.addHiddenApiExemptions("") } catch (_: Throwable) {}
    }
}
