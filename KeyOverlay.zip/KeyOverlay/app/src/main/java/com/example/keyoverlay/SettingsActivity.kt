package com.example.keyoverlay

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.R as MR

class SettingsActivity : AppCompatActivity() {
    private lateinit var p: Prefs

    private fun reload() {
        try { startService(Intent(this, OverlayService::class.java).setAction(OverlayService.A_RELOAD)) } catch (_: Throwable) {}
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val c: Context = this
        p = Prefs(c)
        val (scroll, page) = Ui.scrollPage(c)
        val title = Ui.text(c, "Settings", 36f, true)
        title.setPadding(0, Ui.dp(c, 16), 0, Ui.dp(c, 20))
        page.addView(title)

        val (mouseCard, mouse) = Ui.section(c, "Mouse and touch")
        mouse.addView(Ui.sliderRow(c, "Sensitivity", 0.2f, 5f, p.sensitivity, { "%.2fx".format(it) },
            { p.sensitivity = it }, { reload() }))
        mouse.addView(Ui.switchRow(c, "Relative mouse (pointer capture)", p.relativeMouse) { p.relativeMouse = it; reload() })
        mouse.addView(Ui.switchRow(c, "Tap empty screen to click", p.tapToClick) { p.tapToClick = it; reload() })
        mouse.addView(Ui.switchRow(c, "Haptic feedback", p.haptics) { p.haptics = it; reload() })
        page.addView(mouseCard)

        val (lookCard, look) = Ui.section(c, "Look")
        look.addView(Ui.sliderRow(c, "Overall opacity", 10f, 100f, p.opacity * 100, { "${it.toInt()}%" },
            { p.opacity = it / 100f }, { reload() }))
        look.addView(Ui.sliderRow(c, "Overall button size", 50f, 200f, p.buttonScale * 100, { "${it.toInt()}%" },
            { p.buttonScale = it / 100f }, { reload() }))
        look.addView(Ui.switchRow(c, "Only show in landscape", p.landscapeOnly) { p.landscapeOnly = it; reload() })
        page.addView(lookCard)

        val (gamesCard, games) = Ui.section(c, "Games")
        games.addView(Ui.text(c, "Package names, comma separated", 14f, false, MR.attr.colorOnSurfaceVariant))
        games.addView(Ui.field(c, "com.mojang.minecraftpe", p.targets) { p.targets = it })
        page.addView(gamesCard)

        val (layoutCard, layout) = Ui.section(c, "Layout")
        layout.addView(Ui.filled(c, "Button editor") { startActivity(Intent(c, EditorActivity::class.java)) })
        layout.addView(Ui.tonal(c, "Import layout (.json)") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE)
            }, 77)
        })
        layout.addView(Ui.tonal(c, "Reset layout") { p.resetLayout(); reload(); Toast.makeText(c, "Layout reset", Toast.LENGTH_SHORT).show() })
        page.addView(layoutCard)
        setContentView(scroll)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 77 || res != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
            val list = LayoutImporter.parse(text)
            if (list.isEmpty()) { Toast.makeText(this, "No buttons found in file", Toast.LENGTH_LONG).show(); return }
            p.saveLayout(list); reload()
            Toast.makeText(this, "Imported ${list.size} buttons", Toast.LENGTH_LONG).show()
        } catch (t: Throwable) {
            Toast.makeText(this, "Import failed: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }
}
