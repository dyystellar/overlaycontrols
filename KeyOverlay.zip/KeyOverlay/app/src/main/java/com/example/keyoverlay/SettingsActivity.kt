package com.example.keyoverlay

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.*

class SettingsActivity : Activity() {
    private lateinit var p: Prefs
    private lateinit var layoutList: MutableList<Btn>

    private fun reload() { startService(Intent(this, OverlayService::class.java).setAction(OverlayService.A_RELOAD)) }

    private fun slider(name: String, min: Int, max: Int, cur: Int, fmt: (Int) -> String, set: (Int) -> Unit): LinearLayout {
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, 16, 0, 16) }
        val t = TextView(this).apply { text = "$name: ${fmt(cur)}" }
        val s = SeekBar(this).apply {
            this.max = max - min; progress = cur - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, v: Int, u: Boolean) { t.text = "$name: ${fmt(v + min)}"; set(v + min) }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) { reload() }
            })
        }
        l.addView(t); l.addView(s); return l
    }

    private fun switch(name: String, cur: Boolean, set: (Boolean) -> Unit) = Switch(this).apply {
        text = name; isChecked = cur; setPadding(0, 16, 0, 16)
        setOnCheckedChangeListener { _, c -> set(c); reload() }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        p = Prefs(this); layoutList = p.layout()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 80) }
        root.addView(TextView(this).apply { text = "Settings"; textSize = 24f })
        root.addView(slider("Mouse sensitivity", 20, 500, (p.sensitivity * 100).toInt(), { "%.2fx".format(it / 100f) }) { p.sensitivity = it / 100f })
        root.addView(slider("Opacity", 10, 100, (p.opacity * 100).toInt(), { "$it%" }) { p.opacity = it / 100f })
        root.addView(slider("Button size", 50, 200, (p.buttonScale * 100).toInt(), { "$it%" }) { p.buttonScale = it / 100f })
        root.addView(switch("Relative mouse (pointer capture style)", p.relativeMouse) { p.relativeMouse = it })
        root.addView(switch("Tap empty screen = left click", p.tapToClick) { p.tapToClick = it })
        root.addView(switch("Only show in landscape", p.landscapeOnly) { p.landscapeOnly = it })
        root.addView(switch("Haptic feedback", p.haptics) { p.haptics = it })

        root.addView(TextView(this).apply { text = "Game package names (comma separated)"; setPadding(0, 24, 0, 0) })
        val pk = EditText(this).apply { setText(p.targets); tag = "pk" }
        root.addView(pk)

        root.addView(TextView(this).apply { text = "Controls (show / key binding)"; textSize = 18f; setPadding(0, 32, 0, 8) })
        val keys = (keyList() + layoutList.map { it.key }).distinct(); val names = keys.map { keyName(it) }
        for (btn in layoutList) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(CheckBox(this).apply {
                text = btn.label; isChecked = btn.visible
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setOnCheckedChangeListener { _, c -> btn.visible = c; p.saveLayout(layoutList); reload() }
            })
            row.addView(Spinner(this).apply {
                adapter = ArrayAdapter(this@SettingsActivity, android.R.layout.simple_spinner_dropdown_item, names)
                setSelection(keys.indexOf(btn.key).coerceAtLeast(0))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                    override fun onItemSelected(a: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                        if (keys[pos] != btn.key) { btn.key = keys[pos]; p.saveLayout(layoutList); reload() }
                    }
                    override fun onNothingSelected(a: AdapterView<*>?) {}
                }
            })
            root.addView(row)
        }
        root.addView(TextView(this).apply { text = "Tip: use \"Edit layout\" in the notification to drag buttons."; setPadding(0, 24, 0, 8) })
        root.addView(Button(this).apply {
            text = "Import layout (.json)"
            setOnClickListener {
                startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE)
                }, 77)
            }
        })
        root.addView(Button(this).apply { text = "Reset layout"; setOnClickListener { p.resetLayout(); reload(); recreate() } })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 77 || res != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
            val list = LayoutImporter.parse(text)
            if (list.isEmpty()) { Toast.makeText(this, "No buttons found in file", Toast.LENGTH_LONG).show(); return }
            p.saveLayout(list); reload(); recreate()
            Toast.makeText(this, "Imported ${list.size} buttons", Toast.LENGTH_LONG).show()
        } catch (t: Throwable) {
            Toast.makeText(this, "Import failed: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onPause() {
        super.onPause()
        (findViewById<ViewGroup>(android.R.id.content)).findViewWithTag<EditText>("pk")?.let { p.targets = it.text.toString() }
    }
}
