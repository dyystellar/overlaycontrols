package com.example.keyoverlay

import android.content.pm.PackageManager
import android.os.IBinder
import android.os.SystemClock
import android.util.Log
import android.view.InputDevice
import android.view.InputEvent
import android.view.KeyEvent
import android.view.MotionEvent
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.lang.reflect.Method

/** Injects real keyboard / mouse events through Shizuku (shell privileges). */
object InputInjector {
    private const val TAG = "KeyOverlay"
    private var mgr: Any? = null
    private var inject: Method? = null
    private var sw = 1920f; private var sh = 1080f
    private var cx = 960f; private var cy = 540f
    private var buttons = 0
    private var relative = true

    fun configure(rel: Boolean) { relative = rel }
    fun cursorX() = cx
    fun cursorY() = cy
    fun setScreen(w: Int, h: Int) { sw = w.toFloat(); sh = h.toFloat(); cx = sw / 2; cy = sh / 2 }

    fun ready() = try {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (_: Throwable) { false }

    private fun init(): Boolean {
        if (inject != null) return true
        return try {
            val binder = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("input"))
            val stub = Class.forName("android.hardware.input.IInputManager\$Stub")
            mgr = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
            inject = Class.forName("android.hardware.input.IInputManager")
                .getMethod("injectInputEvent", InputEvent::class.java, Int::class.javaPrimitiveType)
            true
        } catch (t: Throwable) { Log.e(TAG, "init failed", t); false }
    }

    private fun send(e: InputEvent) {
        if (!init()) return
        try { inject!!.invoke(mgr, e, 0) } catch (t: Throwable) { Log.e(TAG, "inject failed", t) }
    }

    fun key(code: Int, down: Boolean) {
        val t = SystemClock.uptimeMillis()
        send(KeyEvent(t, t, if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code, 0, 0, -1, 0, 0, InputDevice.SOURCE_KEYBOARD))
    }

    private fun motion(action: Int, px: Float, py: Float, bs: Int, src: Int, actionButton: Int = 0) {
        val t = SystemClock.uptimeMillis()
        val pp = MotionEvent.PointerProperties().apply { id = 0; toolType = MotionEvent.TOOL_TYPE_MOUSE }
        val pc = MotionEvent.PointerCoords().apply { x = px; y = py; pressure = if (bs != 0) 1f else 0f; size = 1f }
        val e = MotionEvent.obtain(t, t, action, 1, arrayOf(pp), arrayOf(pc), 0, bs, 1f, 1f, 0, 0, src, 0)
        if (actionButton != 0) try {
            MotionEvent::class.java.getMethod("setActionButton", Int::class.javaPrimitiveType).invoke(e, actionButton)
        } catch (_: Throwable) {}
        send(e); e.recycle()
    }

    fun mouseButton(btn: Int, down: Boolean) {
        val flag = if (btn == MOUSE_LEFT) MotionEvent.BUTTON_PRIMARY else MotionEvent.BUTTON_SECONDARY
        val src = InputDevice.SOURCE_MOUSE
        if (down) {
            val first = buttons == 0
            buttons = buttons or flag
            if (first) motion(MotionEvent.ACTION_DOWN, cx, cy, buttons, src)
            motion(MotionEvent.ACTION_BUTTON_PRESS, cx, cy, buttons, src, flag)
        } else {
            buttons = buttons and flag.inv()
            motion(MotionEvent.ACTION_BUTTON_RELEASE, cx, cy, buttons, src, flag)
            if (buttons == 0) motion(MotionEvent.ACTION_UP, cx, cy, 0, src)
        }
    }

    fun move(dx: Float, dy: Float) {
        if (relative) {
            motion(MotionEvent.ACTION_MOVE, dx, dy, buttons, InputDevice.SOURCE_MOUSE_RELATIVE)
        } else {
            cx = (cx + dx).coerceIn(0f, sw); cy = (cy + dy).coerceIn(0f, sh)
            motion(if (buttons != 0) MotionEvent.ACTION_MOVE else MotionEvent.ACTION_HOVER_MOVE, cx, cy, buttons, InputDevice.SOURCE_MOUSE)
        }
    }
}
