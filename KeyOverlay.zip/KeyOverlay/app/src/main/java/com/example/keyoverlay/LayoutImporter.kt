package com.example.keyoverlay

import android.view.KeyEvent
import org.json.JSONObject

/** Converts GoyControls / Zalith-style layout JSON ("custom_buttons") into this app's buttons. */
object LayoutImporter {
    fun keyCode(name: String): Int {
        if (name.isEmpty()) return 0
        if (name == "key.mouse.left") return MOUSE_LEFT
        if (name == "key.mouse.right") return MOUSE_RIGHT
        val n = name.removePrefix("key.keyboard.")
        if (n.length == 1) {
            val c = n[0]
            if (c in 'a'..'z') return KeyEvent.KEYCODE_A + (c - 'a')
            if (c in '0'..'9') return KeyEvent.KEYCODE_0 + (c - '0')
        }
        val fn = if (n.startsWith("f")) n.substring(1).toIntOrNull() else null
        if (fn != null && fn in 1..12) return KeyEvent.KEYCODE_F1 + fn - 1
        return when (n) {
            "space" -> KeyEvent.KEYCODE_SPACE
            "escape" -> KeyEvent.KEYCODE_ESCAPE
            "tab" -> KeyEvent.KEYCODE_TAB
            "enter" -> KeyEvent.KEYCODE_ENTER
            "backspace" -> KeyEvent.KEYCODE_DEL
            "left.shift" -> KeyEvent.KEYCODE_SHIFT_LEFT
            "right.shift" -> KeyEvent.KEYCODE_SHIFT_RIGHT
            "left.control" -> KeyEvent.KEYCODE_CTRL_LEFT
            "right.control" -> KeyEvent.KEYCODE_CTRL_RIGHT
            "left.alt" -> KeyEvent.KEYCODE_ALT_LEFT
            "right.alt" -> KeyEvent.KEYCODE_ALT_RIGHT
            "up" -> KeyEvent.KEYCODE_DPAD_UP
            "down" -> KeyEvent.KEYCODE_DPAD_DOWN
            "left" -> KeyEvent.KEYCODE_DPAD_LEFT
            "right" -> KeyEvent.KEYCODE_DPAD_RIGHT
            "grave.accent" -> KeyEvent.KEYCODE_GRAVE
            "slash" -> KeyEvent.KEYCODE_SLASH
            else -> 0
        }
    }

    fun parse(text: String): List<Btn> {
        val arr = JSONObject(text).getJSONArray("custom_buttons")
        val out = mutableListOf<Btn>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val ks = listOf(keyCode(o.optString("key")), keyCode(o.optString("second_key")), keyCode(o.optString("third_key")))
                .filter { it != 0 }
            if (ks.isEmpty()) continue
            val ls = o.optJSONArray("layouts") ?: continue
            if (ls.length() == 0) continue
            val l = ls.getJSONObject(0)
            val c = l.getJSONArray("center")
            val label = o.optString("custom_label").ifEmpty { keyName(ks[0]) }
            fun colorOf(k: String, d: Int) = if (l.has(k)) l.optLong(k).toInt() else d
            val tog = l.optBoolean("toggleable")
            out += Btn(
                id = "i$i", label = label, key = ks[0], x = c.getDouble(0).toFloat(), y = c.getDouble(1).toFloat(),
                toggle = tog, visible = l.optBoolean("visible_in_game", true),
                hf = l.optDouble("size", 0.1).toFloat(), key2 = ks.getOrElse(1) { 0 }, key3 = ks.getOrElse(2) { 0 },
                shape = l.optInt("shape", 0).coerceIn(0, 2), wr = l.optDouble("width_ratio", 1.0).toFloat(),
                fill = colorOf("button_color", DEF_FILL), stroke = colorOf("stroke_color", DEF_STROKE),
                onFill = colorOf(if (tog) "on_toggle_color" else "on_click_color", DEF_ON),
                strokeW = l.optDouble("stroke_size", 1.5).toFloat(),
                corner = (l.optDouble("roundness", 25.0) / 100.0).toFloat().coerceIn(0f, 0.5f)
            )
        }
        return out
    }
}
