package com.example.keyoverlay

import android.Manifest
import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.R as MR
import rikka.shizuku.Shizuku

class MainActivity : AppCompatActivity() {
    private lateinit var rows: LinearLayout

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val c: Context = this
        val (scroll, page) = Ui.scrollPage(c)
        val title = Ui.text(c, "Key Overlay", 30f, true)
        title.setPadding(0, Ui.dp(c, 6), 0, Ui.dp(c, 0))
        page.addView(title)
        val sub = Ui.text(c, "Keyboard and mouse controls for your games", 13f, false, MR.attr.colorOnSurfaceVariant)
        sub.setPadding(0, 0, 0, Ui.dp(c, 10))
        page.addView(sub)

        val (setupCard, setupBox) = Ui.section(c, "Setup")
        rows = LinearLayout(c)
        rows.orientation = LinearLayout.VERTICAL
        setupBox.addView(rows)
        page.addView(setupCard)

        val (actCard, actBox) = Ui.section(c, "Controls")
        val btnRow = LinearLayout(c)
        btnRow.orientation = LinearLayout.HORIZONTAL
        fun rb(v: View, last: Boolean = false) = btnRow.addView(v, LinearLayout.LayoutParams(0, -2, 1f).apply { if (!last) rightMargin = Ui.dp(c, 6) })
        rb(Ui.filled(c, "Button editor", true) { startActivity(Intent(c, EditorActivity::class.java)) })
        rb(Ui.filled(c, "Hotbar", true) { startActivity(Intent(c, HotbarActivity::class.java)) }, true)
        actBox.addView(btnRow)
        val btnRow2 = LinearLayout(c)
        btnRow2.orientation = LinearLayout.HORIZONTAL
        btnRow2.addView(Ui.tonal(c, "Settings", true) { startActivity(Intent(c, SettingsActivity::class.java)) },
            LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = Ui.dp(c, 6) })
        btnRow2.addView(Ui.tonal(c, "Stop", true) {
            startService(Intent(c, OverlayService::class.java).setAction(OverlayService.A_STOP))
        }, LinearLayout.LayoutParams(0, -2, 1f))
        actBox.addView(btnRow2)
        page.addView(actCard)

        val (tipCard, tipBox) = Ui.section(c, "How it works", true)
        tipBox.addView(Ui.text(c, "Open your game in landscape. The overlay appears on its own. Chips at the top: GAME/MENU switches between sending input and letting touches through; MOUSE shows a pointer you steer by swiping.", 13f, false, MR.attr.colorOnSecondaryContainer))
        page.addView(tipCard)
        setContentView(scroll)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun usageOk(): Boolean {
        val m = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        return m.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    private fun row(label: String, ok: Boolean, act: () -> Unit) {
        val c: Context = this
        val r = LinearLayout(c)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(0, Ui.dp(c, 3), 0, Ui.dp(c, 3))
        val dot = View(c)
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(if (ok) 0xFF2E7D32.toInt() else 0xFFC62828.toInt())
        dot.background = g
        r.addView(dot, LinearLayout.LayoutParams(Ui.dp(c, 12), Ui.dp(c, 12)).apply { rightMargin = Ui.dp(c, 14) })
        r.addView(Ui.text(c, label, 15f), LinearLayout.LayoutParams(0, -2, 1f))
        if (ok) r.addView(Ui.text(c, "Ready", 14f, false, MR.attr.colorOnSurfaceVariant))
        else r.addView(Ui.tonal(c, "Grant", true) { act() }, LinearLayout.LayoutParams(-2, -2))
        rows.addView(r)
    }

    override fun onResume() {
        super.onResume()
        val c: Context = this
        val overlay = Settings.canDrawOverlays(c)
        val usage = usageOk()
        val notif = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val shiz = InputInjector.ready()
        rows.removeAllViews()
        row("Draw over other apps", overlay) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        row("Usage access (detect game)", usage) { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        row("Notifications", notif) {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        row("Shizuku (real mouse and keys)", shiz) {
            try { if (Shizuku.pingBinder()) Shizuku.requestPermission(2) else toast("Start the Shizuku app first") }
            catch (_: Throwable) { toast("Shizuku not available") }
        }
        if (overlay && usage && notif) {
            try { startForegroundService(Intent(c, OverlayService::class.java)) } catch (_: Throwable) {}
        }
    }
}
