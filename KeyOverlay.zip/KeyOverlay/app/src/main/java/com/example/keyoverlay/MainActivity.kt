package com.example.keyoverlay

import android.Manifest
import android.app.Activity
import android.app.AppOpsManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Process
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 40) }
        status = TextView(this).apply { textSize = 16f }
        root.addView(status)
        fun btn(t: String, a: () -> Unit) = root.addView(Button(this).apply { text = t; setOnClickListener { a() } })
        btn("1. Allow draw over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }
        btn("2. Allow usage access (detect game)") { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        btn("3. Allow notifications") {
            if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        btn("4. Grant Shizuku access") {
            try { if (Shizuku.pingBinder()) Shizuku.requestPermission(2) else toast("Start the Shizuku app first") }
            catch (_: Throwable) { toast("Shizuku not available") }
        }
        btn("Settings") { startActivity(Intent(this, SettingsActivity::class.java)) }
        btn("Stop service") { startService(Intent(this, OverlayService::class.java).setAction(OverlayService.A_STOP)) }
        setContentView(root)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun usageOk(): Boolean {
        val m = getSystemService(APP_OPS_SERVICE) as AppOpsManager
        @Suppress("DEPRECATION")
        return m.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }

    override fun onResume() {
        super.onResume()
        val overlay = Settings.canDrawOverlays(this)
        val usage = usageOk()
        val notif = Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        val shiz = InputInjector.ready()
        fun m(v: Boolean) = if (v) "OK" else "missing"
        status.text = "Overlay: ${m(overlay)}\nUsage access: ${m(usage)}\nNotifications: ${m(notif)}\nShizuku: ${m(shiz)}"
        if (overlay && usage && notif) startForegroundService(Intent(this, OverlayService::class.java))
    }
}
