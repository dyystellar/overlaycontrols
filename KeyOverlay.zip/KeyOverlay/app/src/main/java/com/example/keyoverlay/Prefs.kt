package com.example.keyoverlay

import android.content.Context
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject

const val MOUSE_LEFT = -1
const val MOUSE_RIGHT = -2
const val DEF_FILL = 0x66000000
const val DEF_STROKE = -1
val DEF_ON = 0xB3FFFFFF.toInt()

/** One on-screen button. x/y = centre as fraction of screen, hf = diameter as fraction of screen height. */
data class Btn(
    var id: String, var label: String, var key: Int,
    var x: Float, var y: Float, var size: Float = 1f,
    var toggle: Boolean = false, var visible: Boolean = true,
    var hf: Float = 0.12f, var key2: Int = 0, var key3: Int = 0,
    var shape: Int = 0,            // 0 circle, 1 rounded square, 2 pill
    var wr: Float = 1f,            // width ratio
    var fill: Int = DEF_FILL, var stroke: Int = DEF_STROKE, var onFill: Int = DEF_ON,
    var alpha: Float = 1f, var strokeW: Float = 1.5f, var corner: Float = 0.25f
) { var on = false }

fun keyName(code: Int) = when (code) {
    0 -> "None"
    MOUSE_LEFT -> "MOUSE_LEFT"; MOUSE_RIGHT -> "MOUSE_RIGHT"
    else -> KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
}

fun keyList(): List<Int> {
    val l = mutableListOf(MOUSE_LEFT, MOUSE_RIGHT)
    l += (KeyEvent.KEYCODE_A..KeyEvent.KEYCODE_Z)
    l += (KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9)
    l += listOf(KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_CTRL_LEFT,
        KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_TAB, KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_ENTER,
        KeyEvent.KEYCODE_SLASH, KeyEvent.KEYCODE_GRAVE, KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
        KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT)
    l += (KeyEvent.KEYCODE_F1..KeyEvent.KEYCODE_F12)
    return l
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    var sensitivity: Float
        get() = sp.getFloat("sens", 1.5f)
        set(v) { sp.edit().putFloat("sens", v).apply() }
    var opacity: Float
        get() = sp.getFloat("opacity", 1f)
        set(v) { sp.edit().putFloat("opacity", v).apply() }
    var buttonScale: Float
        get() = sp.getFloat("scale", 1f)
        set(v) { sp.edit().putFloat("scale", v).apply() }
    var relativeMouse: Boolean
        get() = sp.getBoolean("relative", true)
        set(v) { sp.edit().putBoolean("relative", v).apply() }
    var tapToClick: Boolean
        get() = sp.getBoolean("tap", true)
        set(v) { sp.edit().putBoolean("tap", v).apply() }
    var landscapeOnly: Boolean
        get() = sp.getBoolean("land", true)
        set(v) { sp.edit().putBoolean("land", v).apply() }
    var haptics: Boolean
        get() = sp.getBoolean("haptics", true)
        set(v) { sp.edit().putBoolean("haptics", v).apply() }
    var active: Boolean
        get() = sp.getBoolean("active", true)
        set(v) { sp.edit().putBoolean("active", v).apply() }
    var targets: String
        get() = sp.getString("targets", "com.mojang.minecraftpe")!!
        set(v) { sp.edit().putString("targets", v).apply() }
    fun targetList() = targets.split(",").map { it.trim() }.filter { it.isNotEmpty() }

    private fun toJson(b: Btn) = JSONObject().put("id", b.id).put("label", b.label).put("key", b.key)
        .put("key2", b.key2).put("key3", b.key3).put("x", b.x.toDouble()).put("y", b.y.toDouble())
        .put("hf", b.hf.toDouble()).put("wr", b.wr.toDouble()).put("toggle", b.toggle).put("visible", b.visible)
        .put("shape", b.shape).put("fill", b.fill).put("stroke", b.stroke).put("onFill", b.onFill)
        .put("alpha", b.alpha.toDouble()).put("strokeW", b.strokeW.toDouble()).put("corner", b.corner.toDouble())

    private fun fromJson(o: JSONObject) = Btn(
        id = o.getString("id"), label = o.getString("label"), key = o.getInt("key"),
        x = o.getDouble("x").toFloat(), y = o.getDouble("y").toFloat(),
        toggle = o.optBoolean("toggle"), visible = o.optBoolean("visible", true),
        hf = o.optDouble("hf", 0.12).toFloat(), key2 = o.optInt("key2", 0), key3 = o.optInt("key3", 0),
        shape = o.optInt("shape", 0), wr = o.optDouble("wr", 1.0).toFloat(),
        fill = o.optInt("fill", DEF_FILL), stroke = o.optInt("stroke", DEF_STROKE), onFill = o.optInt("onFill", DEF_ON),
        alpha = o.optDouble("alpha", 1.0).toFloat(), strokeW = o.optDouble("strokeW", 1.5).toFloat(),
        corner = o.optDouble("corner", 0.25).toFloat()
    )

    fun layout(): MutableList<Btn> {
        val s = sp.getString("layout2", null) ?: return defaultLayout()
        return try {
            val a = JSONArray(s); val out = mutableListOf<Btn>()
            for (i in 0 until a.length()) out += fromJson(a.getJSONObject(i))
            out
        } catch (_: Exception) { defaultLayout() }
    }

    fun saveLayout(l: List<Btn>) {
        val a = JSONArray()
        l.forEach { a.put(toJson(it)) }
        sp.edit().putString("layout2", a.toString()).apply()
    }

    fun resetLayout() { sp.edit().remove("layout2").apply() }

    private fun defaultLayout() = mutableListOf(
        Btn("w", "W", KeyEvent.KEYCODE_W, .14f, .46f, hf = .17f),
        Btn("a", "A", KeyEvent.KEYCODE_A, .065f, .66f, hf = .17f),
        Btn("s", "S", KeyEvent.KEYCODE_S, .14f, .86f, hf = .17f),
        Btn("d", "D", KeyEvent.KEYCODE_D, .215f, .66f, hf = .17f),
        Btn("sprint", "RUN", KeyEvent.KEYCODE_CTRL_LEFT, .25f, .44f, hf = .13f, toggle = true),
        Btn("sneak", "SNEAK", KeyEvent.KEYCODE_SHIFT_LEFT, .14f, .66f, hf = .16f, toggle = true),
        Btn("jump", "JUMP", KeyEvent.KEYCODE_SPACE, .89f, .60f, hf = .19f),
        Btn("hit", "HIT", MOUSE_LEFT, .79f, .40f, hf = .25f),
        Btn("use", "PLACE", MOUSE_RIGHT, .70f, .62f, hf = .17f),
        Btn("esc", "ESC", KeyEvent.KEYCODE_ESCAPE, .04f, .07f, hf = .07f),
        Btn("chat", "CHAT", KeyEvent.KEYCODE_T, .45f, .07f, hf = .08f),
        Btn("view", "F5", KeyEvent.KEYCODE_F5, .55f, .07f, hf = .08f),
        Btn("drop", "Q", KeyEvent.KEYCODE_Q, .65f, .07f, hf = .08f),
        Btn("inv", "INV", KeyEvent.KEYCODE_E, .67f, .93f, hf = .08f)
    )
}
