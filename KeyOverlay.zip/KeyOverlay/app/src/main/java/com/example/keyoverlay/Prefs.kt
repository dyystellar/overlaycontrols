package com.example.keyoverlay

import android.content.Context
import android.view.KeyEvent
import org.json.JSONArray
import org.json.JSONObject

const val MOUSE_LEFT = -1
const val MOUSE_RIGHT = -2

data class Btn(
    var id: String, var label: String, var key: Int,
    var x: Float, var y: Float, var size: Float = 1f,
    var toggle: Boolean = false, var visible: Boolean = true
) { var on = false }

fun keyName(code: Int) = when (code) {
    MOUSE_LEFT -> "MOUSE_LEFT"; MOUSE_RIGHT -> "MOUSE_RIGHT"
    else -> KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
}

fun keyList(): List<Int> {
    val l = mutableListOf(MOUSE_LEFT, MOUSE_RIGHT)
    l += (KeyEvent.KEYCODE_A..KeyEvent.KEYCODE_Z)
    l += (KeyEvent.KEYCODE_0..KeyEvent.KEYCODE_9)
    l += listOf(KeyEvent.KEYCODE_SPACE, KeyEvent.KEYCODE_SHIFT_LEFT, KeyEvent.KEYCODE_CTRL_LEFT,
        KeyEvent.KEYCODE_ALT_LEFT, KeyEvent.KEYCODE_TAB, KeyEvent.KEYCODE_ESCAPE, KeyEvent.KEYCODE_ENTER,
        KeyEvent.KEYCODE_SLASH, KeyEvent.KEYCODE_GRAVE)
    l += (KeyEvent.KEYCODE_F1..KeyEvent.KEYCODE_F12)
    return l
}

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("cfg", Context.MODE_PRIVATE)

    var sensitivity: Float
        get() = sp.getFloat("sens", 1.5f)
        set(v) { sp.edit().putFloat("sens", v).apply() }
    var opacity: Float
        get() = sp.getFloat("opacity", 0.6f)
        set(v) { sp.edit().putFloat("opacity", v).apply() }
    var buttonScale: Float
        get() = sp.getFloat("scale", 1f)
        set(v) { sp.edit().putFloat("scale", v).apply() }
    var relativeMouse: Boolean
        get() = sp.getBoolean("relative", true)
        set(v) { sp.edit().putBoolean("relative", v).apply() }
    var tapToClick: Boolean
        get() = sp.getBoolean("tap", true)
        set(v) { sp.edit().putBoolean("tap", v).apply() }
    var landscapeOnly: Boolean
        get() = sp.getBoolean("land", true)
        set(v) { sp.edit().putBoolean("land", v).apply() }
    var haptics: Boolean
        get() = sp.getBoolean("haptics", true)
        set(v) { sp.edit().putBoolean("haptics", v).apply() }
    var active: Boolean
        get() = sp.getBoolean("active", true)
        set(v) { sp.edit().putBoolean("active", v).apply() }
    var targets: String
        get() = sp.getString("targets", "com.mojang.minecraftpe")!!
        set(v) { sp.edit().putString("targets", v).apply() }
    fun targetList() = targets.split(",").map { it.trim() }.filter { it.isNotEmpty() }

    fun layout(): MutableList<Btn> {
        val s = sp.getString("layout", null) ?: return defaultLayout()
        return try {
            val a = JSONArray(s); val out = mutableListOf<Btn>()
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                out += Btn(o.getString("id"), o.getString("label"), o.getInt("key"), o.getDouble("x").toFloat(),
                    o.getDouble("y").toFloat(), o.getDouble("size").toFloat(), o.getBoolean("toggle"), o.getBoolean("visible"))
            }
            out
        } catch (_: Exception) { defaultLayout() }
    }

    fun saveLayout(l: List<Btn>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("id", it.id).put("label", it.label).put("key", it.key).put("x", it.x.toDouble())
            .put("y", it.y.toDouble()).put("size", it.size.toDouble()).put("toggle", it.toggle).put("visible", it.visible)) }
        sp.edit().putString("layout", a.toString()).apply()
    }

    fun resetLayout() { sp.edit().remove("layout").apply() }

    private fun defaultLayout() = mutableListOf(
        Btn("w", "W", KeyEvent.KEYCODE_W, .14f, .52f),
        Btn("a", "A", KeyEvent.KEYCODE_A, .07f, .70f),
        Btn("s", "S", KeyEvent.KEYCODE_S, .14f, .86f),
        Btn("d", "D", KeyEvent.KEYCODE_D, .21f, .70f),
        Btn("sprint", "Run", KeyEvent.KEYCODE_CTRL_LEFT, .27f, .50f),
        Btn("jump", "Jump", KeyEvent.KEYCODE_SPACE, .90f, .60f, 1.2f),
        Btn("sneak", "Sneak", KeyEvent.KEYCODE_SHIFT_LEFT, .78f, .84f, 1f, true),
        Btn("hit", "Hit", MOUSE_LEFT, .92f, .84f),
        Btn("use", "Use", MOUSE_RIGHT, .76f, .62f),
        Btn("esc", "Esc", KeyEvent.KEYCODE_ESCAPE, .04f, .08f, .8f),
        Btn("chat", "Chat", KeyEvent.KEYCODE_T, .12f, .08f, .8f),
        Btn("view", "View", KeyEvent.KEYCODE_F5, .74f, .08f, .8f),
        Btn("drop", "Drop", KeyEvent.KEYCODE_Q, .82f, .08f, .8f),
        Btn("inv", "Inv", KeyEvent.KEYCODE_E, .90f, .08f, .8f)
    )
}
